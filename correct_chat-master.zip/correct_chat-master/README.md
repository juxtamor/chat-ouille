# correct_chat
Correction type du chat (un peu amélioré)
