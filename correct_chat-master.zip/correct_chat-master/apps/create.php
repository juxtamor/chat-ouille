<?php
require('views/create.phtml');
?>