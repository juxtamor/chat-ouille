<?php
require('views/skel.phtml');
?>