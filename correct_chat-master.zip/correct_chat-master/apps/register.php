<?php
require('views/register.phtml');
?>