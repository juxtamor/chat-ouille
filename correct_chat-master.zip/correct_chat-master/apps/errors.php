<?php
var_dump($_POST);
if (count($errors) > 0)
{
	require("views/errors.phtml");
}
?>