<?php
require('views/tchat.phtml');
?>