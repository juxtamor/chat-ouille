<?php
require('views/container.phtml');
?>